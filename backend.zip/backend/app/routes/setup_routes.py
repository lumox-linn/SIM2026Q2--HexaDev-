from flask import Blueprint, jsonify
import os

setup_bp = Blueprint('setup', __name__)


@setup_bp.route('/setup', methods=['GET'])
def setup():
    """Temporary endpoint — creates all tables and seeds accounts."""
    try:
        import pymysql
        from werkzeug.security import generate_password_hash

        conn = pymysql.connect(
            host=os.getenv('MYSQL_HOST', 'localhost'),
            user=os.getenv('MYSQL_USER', 'root'),
            password=os.getenv('MYSQL_PASSWORD', ''),
            database=os.getenv('MYSQL_DB', 'csit314'),
            port=int(os.getenv('MYSQL_PORT', 3306)),
            ssl_disabled=True,
        )
        cursor = conn.cursor()

        # Create userprofile table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS `userprofile` (
              `profile_id`   INT(8)       NOT NULL AUTO_INCREMENT,
              `profile_name` VARCHAR(50)  NOT NULL,
              `status`       ENUM('active','suspended') NOT NULL DEFAULT 'active',
              `description`  VARCHAR(255) DEFAULT NULL,
              `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
              PRIMARY KEY (`profile_id`),
              UNIQUE KEY `profile_name` (`profile_name`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """)

        # Create useraccount table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS `useraccount` (
              `user_id`         INT(8)       NOT NULL AUTO_INCREMENT,
              `username`        VARCHAR(50)  NOT NULL,
              `password_hash`   VARCHAR(255) NOT NULL,
              `isActive`        TINYINT(1)   NOT NULL DEFAULT 1,
              `role`            ENUM('admin','fund_raiser','donee','platform_manager') NOT NULL,
              `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
              `profile_picture` VARCHAR(255) DEFAULT NULL,
              `email`           VARCHAR(100) DEFAULT NULL,
              `dob`             DATE         DEFAULT NULL,
              `phone`           VARCHAR(20)  DEFAULT NULL,
              `profile_id`      INT(8)       DEFAULT NULL,
              PRIMARY KEY (`user_id`),
              UNIQUE KEY `username` (`username`),
              FOREIGN KEY (`profile_id`) REFERENCES `userprofile`(`profile_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """)

        # Create category table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS `category` (
              `category_id`   INT          NOT NULL AUTO_INCREMENT,
              `category_name` VARCHAR(100) NOT NULL UNIQUE,
              `description`   TEXT,
              `status`        VARCHAR(20)  NOT NULL DEFAULT 'active',
              `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
              PRIMARY KEY (`category_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """)

        # Create activity table — Sprint 4
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS `activity` (
              `activity_id`   INT            NOT NULL AUTO_INCREMENT,
              `title`         VARCHAR(200)   NOT NULL,
              `description`   TEXT,
              `category_id`   INT            DEFAULT NULL,
              `created_by`    INT            NOT NULL,
              `target_amount` DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
              `amount_raised` DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
              `start_date`    DATE           DEFAULT NULL,
              `end_date`      DATE           DEFAULT NULL,
              `status`        VARCHAR(20)    NOT NULL DEFAULT 'active',
              `created_at`    DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
              PRIMARY KEY (`activity_id`),
              FOREIGN KEY (`category_id`) REFERENCES `category`(`category_id`) ON DELETE SET NULL,
              FOREIGN KEY (`created_by`)  REFERENCES `useraccount`(`user_id`)  ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """)

        conn.commit()

        # Seed default profiles
        profiles = [
            ('admin',            'active', 'System administrator'),
            ('fund_raiser',      'active', 'Creates and manages fundraising campaigns'),
            ('donee',            'active', 'Browses and saves fundraising activities'),
            ('platform_manager', 'active', 'Manages categories and generates reports'),
        ]
        for profile in profiles:
            try:
                cursor.execute(
                    "INSERT IGNORE INTO userprofile (profile_name, status, description) VALUES (%s, %s, %s)",
                    profile
                )
            except Exception:
                pass

        conn.commit()

        # Seed demo accounts
        users = [
            ('admin01',     generate_password_hash('admin123'),   1, 'admin'),
            ('fr01',        generate_password_hash('fr123'),      1, 'fund_raiser'),
            ('donee01',     generate_password_hash('donee123'),   1, 'donee'),
            ('pm01',        generate_password_hash('pm123'),      1, 'platform_manager'),
            ('suspended01', generate_password_hash('test123'),    0, 'donee'),
        ]

        inserted = 0
        for user in users:
            try:
                cursor.execute(
                    "INSERT IGNORE INTO useraccount (username, password_hash, isActive, role) VALUES (%s, %s, %s, %s)",
                    user
                )
                inserted += cursor.rowcount
            except Exception:
                pass

        conn.commit()

        # Update profile_id FK for all accounts
        cursor.execute("""
            UPDATE useraccount ua
            JOIN userprofile up ON ua.role = up.profile_name
            SET ua.profile_id = up.profile_id
            WHERE ua.profile_id IS NULL
        """)
        conn.commit()
        cursor.close()
        conn.close()

        return jsonify({
            'status':  'success',
            'message': f'All tables created! {inserted} accounts seeded.',
            'tables':  ['userprofile', 'useraccount', 'category', 'activity'],
            'accounts': [
                {'username': 'admin01',     'password': 'admin123',  'role': 'admin'},
                {'username': 'fr01',        'password': 'fr123',     'role': 'fund_raiser'},
                {'username': 'donee01',     'password': 'donee123',  'role': 'donee'},
                {'username': 'pm01',        'password': 'pm123',     'role': 'platform_manager'},
                {'username': 'suspended01', 'password': 'test123',   'role': 'donee (suspended)'},
            ]
        }), 200

    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500